Ycad_api_readme1_a.txt - 5 June 2003

Using Ycad to render a DXF drawing to a user supplied Graphics object.


This document describes how to access the Ycad API in order to
render a DXF drawing file into a user supplied Java Graphics object.

A commented code example containing three methods follows.

The methods are:

-- BufferedImage createEffect_ycadv1(String ycadv1PropertiesString, int img_width, int img_height)
   This method takes a String describing the drawing and font sources,
   rendering options and drawing boundries, size of image to create.

-- void createEffect_ycadv1_render(String ycadv1PropertiesString, Graphics jgc)
   Processes the properties string (ycadv1PropertiesString), starts
   input and renders the image into jgc (Java Graphics Context).

-- void createEffect_ycadv1_processProperties(String ycadv1Properties, YutilProperties props_user, Yxxf D)
   Parses the properties string into a properties object (props_user).
   Sets up the input parameters in the drawing (D) which
   describe where the input is located.


Annotation notes such as "N01" to the left of the source listings
link to the following notes:

In createEffect_ycadv1():
N01 - Create a BufferedImage to render the drawing into.
N02 - Calling the rendering method.

In createEffect_ycadv1_render():
N03 - Creating a drawing object (Yxxf) to hold the DXF file.
N04 - Creating an input processor (get handler).
N05 - Setting up the parameter string describing the input
      and rendering options.
N06 - Setting up and starting the view renderer (handler).
N07 - Starting the DXF input process.
N08 - Imprinting the image.

In createEffect_ycadv1_processProperties():
N09 - Loads properties object from String.
N10 - Scan thru all user properties.
N11 - Set up main drawing source (in D).
N12 - Set up style (SHX font files) source (in D).
N13 - Final processing of font files.


-- Main routine

An example call to these methods might look like:

    BufferedImage bufimg = createEffect_ycadv1
        ("src=dat/test1.dxf stylesrc=dat/fonts/txt.shx bgcolor=#FF0000 width=640 height=480",
         640, 480, null);

This will return a new BufferedImage with DXF drawing rendered into it.

Note: The last parameter (null in this case) is used if the methods are
part of an Applet. If so, pass the Applet reference for use by the input methods.


End of Document - source follows (remove the Nxx notes before use).


    //==========================================================================
    /**
     * Create effect layer - Ycadv type 1 - DXF file view imprint.
     */
    private BufferedImage createEffect_ycadv1(String ycadv1PropertiesString
                                              int img_width, int img_height, Applet applet)
    {
        // Create image
        BufferedImage ycadv1image = new BufferedImage(img_width, img_height,
                                                      BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = ycadv1image.createGraphics();


        // Imprint image
        // ====

        // Prepend bounds to properties string
N01     ycadv1PropertiesString = "xoffset=" + 0 + " " +
                                 "yoffset=" + 0 + " " +
                                 "width="   + ycadv1image.getWidth() + " " +
                                 "height="  + ycadv1image.getHeight() + " " +
                                 ycadv1PropertiesString;

N02     createEffect_ycadv1_render(ycadv1PropertiesString, g2, applet);

        // ====


        g2.dispose();


        return ycadv1image;
    }
    //==========================================================================


    //==========================================================================
    /**
     * Create effect layer - Ycadv type 1 - DXF file view imprint.
     *<UL>
     *   <LI> Set up drawing:
     *   <LI> - Create drawing
     *   <LI> - Create I/O handler and I/O name in drawing
     *   <LI> - Create Get handler
     *   <LI> Process properties - sets I/O name values
     *   <LI> Set up view handler
     *   <LI> - Create view handler
     *   <LI> Start Input with drawing - viewer is rolling
     *</UL>
     */
    private void createEffect_ycadv1_render(String ycadv1PropertiesString,
                                            Graphics jgc, Applet applet)
    {
        // System.out.println("++ycadv1:render|BEG");
        // System.out.println("++ycadv1:render|str=[" + ycadv1PropertiesString + "]");
        // System.out.println("++ycadv1:render|jgc=[" + jgc + "]");
        // System.out.println("++ycadv1:render|bnd=[" + xoffset + ":" + yoffset + ":" + width + ":" + height + "]");

        if (ycadv1PropertiesString == null)
        {
            System.out.println("++ycadv1:render|parameter error, ycadv1PropertiesString=null");
            System.out.println("++ycadv1:render|END");
            return;
        }
        if (jgc == null)
        {
            System.out.println("++ycadv1:render|parameter error, jgc=null");
            System.out.println("++ycadv1:render|END");
            return;
        }


N03     // ============================================================
        // Set up drawing
        //
        // Create drawing
        // Create I/O handler and I/O name in drawing
        // Create Get handler
        // ============================================================

        // Create drawing
        Yxxf D = new Yxxf();

        // Create I/O Handler
N04     if (applet == null)
            D.iohandler = new YutilIOHandler();
        else
            D.iohandler = new YutilIOHandler(applet);

        // Create empty main drawing ioname
        D.ioname = new YutilIOHandlerName("main");


        // Create Get Handler
        YdxfGetHandler gethandler = new YdxfGetHandler();




N05     // ============================================================
        // Create and set user properties (props_user)
        // Sets I/O name values
        // ============================================================
        YutilProperties props_user = new YutilProperties();

        // Set bounds defaults (file and url have none)      
        props_user.setPropertiesDefaults("xoffset=" + 0, false);
        props_user.setPropertiesDefaults("yoffset=" + 0, false);
        props_user.setPropertiesDefaults("width="   + 160, false);
        props_user.setPropertiesDefaults("height="  + 120, false);

        // Process properties string populating props_user and Drawing I/O structure.
        createEffect_ycadv1_processProperties(ycadv1PropertiesString, props_user, D);

        // Extract bounds
        int param_xoffset = props_user.getProperty_int("xoffset");
        int param_yoffset = props_user.getProperty_int("yoffset");
        int param_width   = props_user.getProperty_int("width");
        int param_height  = props_user.getProperty_int("height");




N06     // ============================================================
        // Create view handler
        // Get viewer panel from view handler and add to Applet
        // ============================================================
        // System.out.println("++ycadv1:render|setting up view");

        //
        // Create view handler (Observer)
        //
        YxxfPrtViewHandler vhandler = new YxxfPrtViewHandler();

        // Set parameters in view handler
        // Copy in all properties from props_user that are not used here
        for (Enumeration ep = props_user.propertyNames(); ep.hasMoreElements(); )
        {
            String key = ((String)ep.nextElement()).toLowerCase();
            String keylower = key.toLowerCase();

            if (!keylower.equals("baseurl") &&
                !keylower.equals("src") &&
                !keylower.equals("srcfile") &&
                !keylower.equals("srcurl") &&
                !keylower.startsWith("stylesrc") &&
                !keylower.startsWith("stylesrcfile") &&
                !keylower.startsWith("stylesrcurl"))
            {
                String val = key + "=" + props_user.getProperty(key);
                vhandler.setProperties(val, false);
            }
        }
        vhandler.commandViewHandler_command_init(D, jgc);
        vhandler.commandViewHandler_command_start();


N07     // ============================================================
        // Start Input
        // ============================================================
        // Start get drawing
        // System.out.println("++ycadv1:render|BEG gethandler.commandGetStart");
        gethandler.commandGetStart(D);
        // System.out.println("++ycadv1:render|END gethandler.commandGetStart");


        // ============================================================
        // Wait for completion
        // ============================================================
        // System.out.println("++ycadv1:render|BEG vhandler.commandViewHandler_command_wait_for_complete");

        vhandler.waitDrawingViewReady();
        // for (int i = 0; i < 12; i++)
        //     vhandler.commandViewHandler_toolbar_zoom_in();
        // vhandler.commandViewHandler_toolbar_zoom_out();
N08     vhandler.commandViewHandler_toolbar_redraw();
        vhandler.commandViewHandler_command_wait_for_complete();
        // System.out.println("++ycadv1:render|END vhandler.commandViewHandler_command_wait_for_complete");


        // System.out.println("++ycadv1:render|END");
    }
    //==========================================================================


    //==========================================================================
    /**
     * Process properties.
     *<UL>
     *  <LI>Set defaults (file and url have none).
     *  <LI>Load properties.
     *  <LI>Set local params.
     *  <LI>All user params examined - do post processing of source names.
     *</UL>
     */
    private
    void createEffect_ycadv1_processProperties(String ycadv1Properties, YutilProperties props_user, Yxxf D)
    {
        // Load properties
N09     props_user.setProperties(ycadv1Properties, true);


        // Set local params
        // System.out.println("++ycadv1:processProperties|props_user BEG");
N10     for (Enumeration e = props_user.propertyNames(); e.hasMoreElements(); )
        {
            String key = (String)e.nextElement();
            String val = props_user.getProperty(key);
            // System.out.println("++ycadv1:processProperties|key=[" + key + "],val=[" + val + "]");

            String keylower = key.toLowerCase();


N11         //
            // Main drawing source
            //
            if (keylower.equals("baseurl"))
            {   // Base URL for all sources
                D.ioname.baseurl = val;
            }
            else


            if (keylower.equals("src"))
            {
                D.ioname.src = val;
            }
            else

            if (keylower.equals("srcfile"))
            {
                D.ioname.srcfile = val;
            }
            else

            if (keylower.equals("srcurl"))
            {
                D.ioname.srcurl = val;
            }
            else


N12         //
            // Style shape source
            //
            if (keylower.startsWith("stylesrc") ||
                keylower.startsWith("stylesrcfile") ||
                keylower.startsWith("stylesrcurl"))
            {
                String stylename = ""; // Default style name is empty string

                // Extract style name from key name
                if (keylower.startsWith("stylesrc"))
                {
                    if (keylower.length() > 8)
                        stylename = keylower.substring(8).toUpperCase();
                }
                else
                if (keylower.startsWith("stylesrcfile"))
                {
                    if (keylower.length() > 12)
                        stylename = keylower.substring(12).toUpperCase();
                }
                else
                if (keylower.startsWith("stylesrcurl"))
                {
                    if (keylower.length() > 11)
                        stylename = keylower.substring(11).toUpperCase();
                }


                // Find matching style element
                YxxfTblStyle style = D.secTables.findStyle_add(stylename);

                if (style.shape == null)
                {
                    style.shape = new YxxfShape(); // all styles will use shapes
                }

                if (style.shape.ioname == null)
                {   // not set yet, create
                    style.shape.ioname = new YutilIOHandlerName(stylename);
                }


                // Set proper value
                if (keylower.startsWith("stylesrc"))
                    style.shape.ioname.src = val;
                else
                if (keylower.startsWith("stylesrcfile"))
                    style.shape.ioname.srcfile = val;
                else
                if (keylower.startsWith("stylesrcurl"))
                    style.shape.ioname.srcurl = val;
            }

        }
        // System.out.println("++ycadv1:processProperties|props_user END");


N13     // All user params examined - do post processing of source names
        // System.out.println("++ycadv1:processProperties|D.ioname=[" + D.ioname + "]");

        // For each style
        // 1) Set iohandler in each style to match main iohandler
        // 2) Set baseurl in each style ioname to match main ioname
        // System.out.println("++ycadv1:processProperties|style ioname.e_ioname BEG");
        for (Enumeration e_ioname = D.secTables.tblStyle.elements(); e_ioname.hasMoreElements(); ) // eieio
        {
            YxxfTblStyle style = (YxxfTblStyle)e_ioname.nextElement();

            if (style.shape == null)
            {
                continue;
            }

            if (style.shape.ioname == null)
            {
                continue;
            }

            // 1)
            style.shape.iohandler = D.iohandler;

            // 2)
            style.shape.ioname.baseurl = D.ioname.baseurl;
            // System.out.println("++ycadv1:processProperties|style ioname:name=[" + style.getName() + "],ioname=[" + style.shape.ioname + "]");
        }
        // System.out.println("++ycadv1:processProperties|style ioname.e_ioname END");
    }
    //==========================================================================
