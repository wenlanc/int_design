/*
 * JDXF Library
 * 
 *   Copyright (C) 2018, Jonathan Sevy <jsevy@cs.drexel.edu>
 *   
 *   Permission is hereby granted, free of charge, to any person obtaining a copy
 *   of this software and associated documentation files (the "Software"), to deal
 *   in the Software without restriction, including without limitation the rights
 *   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *   copies of the Software, and to permit persons to whom the Software is
 *   furnished to do so, subject to the following conditions:
 *   
 *   The above copyright notice and this permission notice shall be included in all
 *   copies or substantial portions of the Software.
 *   
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *   SOFTWARE.
 * 
 */


package com.jsevy.jdxftest;
 


import java.awt.*;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.io.*;



public class DXFTest extends JFrame
                                implements ActionListener, MouseListener, MouseWheelListener, MouseMotionListener
{   
    
    
    private JMenuBar theMenubar;
    private JMenu fileMenu;
    private JMenuItem quitItem, graphicsItem, textTransformationsItem, graphicsTransformationsItem, layersItem, textItem, graphics2DItem, hatchItem;
    private JMenuItem zoomInItem, zoomOutItem;
    
    private String currentDirectory = null;
    
    private DXFTestPanel dxfTestPanel;
    private JTextArea messagesArea;
    
    
    
    // WindowCloseAdapter to catch window close-box closings
    private class WindowCloseAdapter extends WindowAdapter
    { 
        public void windowClosing(WindowEvent e)
        {
            System.exit(0);
        }
    }
        
        
    
    public DXFTest()
    {
                
        setUpDisplay();
        
        // set current directory to be wherever the jar file is located
        currentDirectory = new File(".").getAbsolutePath();
    }
    
    
    private void setUpDisplay()
    {
        this.setTitle("JDXF Test App");
        
        addWindowListener(new WindowCloseAdapter());
        
        dxfTestPanel = new DXFTestPanel();
        //JScrollPane scrollPane = new JScrollPane(dxfTestPanel);
        dxfTestPanel.addMouseListener(this);
        dxfTestPanel.addMouseWheelListener(this);
        dxfTestPanel.addMouseMotionListener(this);
        
        this.getRootPane().setBorder(new BevelBorder(BevelBorder.RAISED));
        
        theMenubar = new JMenuBar();
        this.setJMenuBar(theMenubar);
        
        
        fileMenu = new JMenu("File");
        
        graphicsItem = new JMenuItem("Test graphics");
        graphicsItem.setActionCommand("graphics");
        graphicsItem.addActionListener(this);
        fileMenu.add(graphicsItem);
        
        graphicsTransformationsItem = new JMenuItem("Test graphics transformations");
        graphicsTransformationsItem.setActionCommand("transformations_graphics");
        graphicsTransformationsItem.addActionListener(this);
        fileMenu.add(graphicsTransformationsItem);
        
        textItem = new JMenuItem("Test text");
        textItem.setActionCommand("text");
        textItem.addActionListener(this);
        fileMenu.add(textItem);
        
        textItem = new JMenuItem("Test font loading");
        textItem.setActionCommand("fonts");
        textItem.addActionListener(this);
        fileMenu.add(textItem);
        
        textTransformationsItem = new JMenuItem("Test text transformations");
        textTransformationsItem.setActionCommand("transformations_text");
        textTransformationsItem.addActionListener(this);
        fileMenu.add(textTransformationsItem);
        
        graphics2DItem = new JMenuItem("Test graphics2D");
        graphics2DItem.setActionCommand("graphics2D");
        graphics2DItem.addActionListener(this);
        fileMenu.add(graphics2DItem);
        
        hatchItem = new JMenuItem("Test hatch");
        hatchItem.setActionCommand("hatch");
        hatchItem.addActionListener(this);
        fileMenu.add(hatchItem);
        
        layersItem = new JMenuItem("Test layers");
        layersItem.setActionCommand("layers");
        layersItem.addActionListener(this);
        fileMenu.add(layersItem);
        
        textItem = new JMenuItem("Test blocks");
        textItem.setActionCommand("blocks");
        textItem.addActionListener(this);
        fileMenu.add(textItem);
        
        quitItem = new JMenuItem("Quit");
        quitItem.setActionCommand("quit");
        quitItem.addActionListener(this);
        fileMenu.add(quitItem);
        
        fileMenu.add(new JMenuItem("-"));
        
        zoomInItem = new JMenuItem("Zoom in");
        zoomInItem.setActionCommand("zoom_in");
        zoomInItem.addActionListener(this);
        zoomInItem.setAccelerator(KeyStroke.getKeyStroke('+'));
        fileMenu.add(zoomInItem);
        
        zoomOutItem = new JMenuItem("Zoom out");
        zoomOutItem.setActionCommand("zoom_out");
        zoomOutItem.addActionListener(this);
        zoomOutItem.setAccelerator(KeyStroke.getKeyStroke('-'));
        fileMenu.add(zoomOutItem);
        
        fileMenu.add(new JMenuItem("-"));
        
        theMenubar.add(fileMenu);
        
        
        
        
        // set size of scroll pane to mostly fill screen
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        dxfTestPanel.setPreferredSize(new Dimension((int)(screenSize.width*(0.80)), (int)(screenSize.height*(0.80))));
        //Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        //scrollPane.setPreferredSize(new Dimension((int)(screenSize.width*(0.80)), (int)(screenSize.height*(0.80))));
        //splineCanvas.setSize(new Dimension(700,500));
        
        
        messagesArea = new JTextArea(3, 60);
        JScrollPane messagesScroll = new JScrollPane(messagesArea);
        
        
        
        // set params for layout manager
        GridBagLayout  theLayout = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.BOTH;
        c.ipadx = 0;
        c.ipady = 0;
        Insets theMargin = new Insets(2,2,2,2);
        c.insets = theMargin;
        c.anchor = GridBagConstraints.CENTER;
        c.weightx = .5;
        c.weighty = .5;
        
        
        this.getContentPane().setLayout(theLayout);
        
        c.gridx = 1;
        c.gridy = 1;
        theLayout.setConstraints(dxfTestPanel, c);
        this.getContentPane().add(dxfTestPanel);
        
        /*
        c.gridx = 1;
        c.gridy = 2;
        c.fill = GridBagConstraints.HORIZONTAL;
        theLayout.setConstraints(messagesScroll, c);
        this.getContentPane().add(messagesScroll);
        */
        
    }
    
    
    
    public void actionPerformed(ActionEvent theEvent)
    {
        String command = theEvent.getActionCommand();
        
    
        if (command.equals("quit"))
        {
            System.exit(0);
        }
        /*
        if (command.equals("graphics") 
                || command.equals("text") 
                || command.equals("transformations_graphics") 
                || command.equals("transformations_text")
                || command.equals("graphics2D"))
        */
        else if(command.equals("zoom_in"))
        {
            dxfTestPanel.setScale(dxfTestPanel.getScale()*2);
        }
        else if(command.equals("zoom_out"))
        {
            dxfTestPanel.setScale(dxfTestPanel.getScale()/2);
        }
        else
        {
            if (command.equals("fonts"))
            {
                selectFontFile();
            }
            
            dxfTestPanel.setDisplayContent(command);
            String dxfString = dxfTestPanel.generateDXF();
            saveProcedure(command + ".dxf", dxfString);
        }
        
    }
    
    
    
    private void saveProcedure(String defaultFilename, String dxfString)
    {
        FileDialog f = new FileDialog(this, "Save", FileDialog.SAVE);
        f.setDirectory(currentDirectory);
        f.setName(defaultFilename);
        f.setVisible(true);

        if (f.getFile() != null)
        {
            currentDirectory = f.getDirectory();
            File designFile = new File(currentDirectory + f.getFile());
            try
            {
                FileWriter fileWriter = new FileWriter(designFile);
                
                fileWriter.write(dxfString);
                
                fileWriter.flush();
                fileWriter.close();
                
            }
            catch (Exception e)
            {
                System.out.println("Exception while writing out design file: " + e.toString());
            }
            
        }
                
    }
    
    
    // put up a dialog to ask for a TrueType font file
    private void selectFontFile()
    {
        FileDialog f = new FileDialog(this, "Open font file", FileDialog.LOAD);
        f.setVisible(true);

        if (f.getFile() != null)
        {
            String fontFilePath = f.getDirectory() + f.getFile();
            dxfTestPanel.setFontFilePath(fontFilePath);            
        }
                
    }
    
    
    
    
    public static void main(String args[]) 
    {
        try
        {
            
            DXFTest theApp = new DXFTest();
            
            theApp.pack();
            
            // tweak app size to make it a little larger than necessary, to address the
            // "shrunken textfields" problem arising from the layout manager packing stuff
            // a little too tightly.
            Dimension dim = theApp.getSize();
            dim.height += 20;
            dim.width += 20;
            theApp.setSize(dim);
            
            theApp.setVisible(true);
            
        }
        catch (Exception e)
        {System.out.println("Problem starting app:" + e.toString());}
    }
    
    
    
    private int mouseStartX = 0;
    private int mouseStartY = 0;
    
    @Override
    public void mouseClicked(MouseEvent e)
    {
        // set as new center
        //dxfTestPanel.setCenter(e.getX(), e.getY());
    }


    @Override
    public void mousePressed(MouseEvent e)
    {
        // TODO Auto-generated method stub
        mouseStartX = e.getX();
        mouseStartY = e.getY();
    }


    @Override
    public void mouseReleased(MouseEvent e)
    {
        // TODO Auto-generated method stub
        
    }


    @Override
    public void mouseEntered(MouseEvent e)
    {
        // TODO Auto-generated method stub
        
    }


    @Override
    public void mouseExited(MouseEvent e)
    {
        // TODO Auto-generated method stub
        
    }


    @Override
    public void mouseWheelMoved(MouseWheelEvent e)
    {
        double clicks = e.getPreciseWheelRotation();
        double scaleAmount = Math.exp(clicks/4);
        dxfTestPanel.setScale(dxfTestPanel.getScale()*scaleAmount);
    }


    @Override
    public void mouseDragged(MouseEvent e)
    {
        int deltaX = e.getX() - mouseStartX;
        int deltaY = e.getY() - mouseStartY;
        
        dxfTestPanel.offsetCenter(deltaX, deltaY);
        
        mouseStartX = e.getX();
        mouseStartY = e.getY();
    }


    @Override
    public void mouseMoved(MouseEvent e)
    {
        // TODO Auto-generated method stub
        
    }
    

}
